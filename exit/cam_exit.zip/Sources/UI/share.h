
int share = 0;
