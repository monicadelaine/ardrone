
static int share = 0;
